import socket
import sys
HOST=''#Symbolic name meaning all available interfaces
PORT=8888#Arbitrary non-privileged port
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
print 'Socket created!'
try:
	s.bind((HOST,PORT))
except socket.error, msg:
	print 'Bind failed.Error code: '+str(msg[0])+' Error message:'+msg[1]
	sys.exit()
print 'Socket bind successfully!'
s.listen(10)
print 'Now socketc listening!'