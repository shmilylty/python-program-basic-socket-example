import socket #for socket
import sys #for exit

try:
	s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
except socket.error, msg:
	print 'Failed to create socket,Error code :'+str(msg[0])+'Error message : '+msg[1]
	sys.exit()
print "Socket Created!"
host='www.baidu.com'
port=80
try:
	remote_ip=socket.gethostbyname(host)
except socket.gaierror:
	print 'Hostname could not be resolved.Exiting!'
	sys.exit()
print 'IP address of '+host+' is '+remote_ip
#Connet to remote server
s.connect((remote_ip,port))
print 'Socket Connet to '+host+' ip: '+remote_ip+' port:'+str(port)
message='''
GET / HTTP/1.1
Host: www.baidu.com
Connection: keep-alive
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
DNT: 1
Accept-Encoding: gzip, deflate, sdch, br
Accept-Language: zh-CN,zh;q=0.8
Cookie: BAIDUID=136CAE21D84C6E203D5548AB346C8D54:FG=1; BIDUPSID=136CAE21D84C6E203D5548AB346C8D54; PSTM=1475136772; BDUSS=3lDYkMyQmQ5SkFkTUJabktiazBBZEplWE5oR2MzQlN6VUdkWllBVkxMdHBYQnhZQVFBQUFBJCQAAAAAAAAAAAEAAAA9N4cpztKyu8rHX9K7sOPIywAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGnP9Fdpz~RXT; __cfduid=d3267763298bbae51d056007507df48811475833453; ispeed_lsm=2; BD_UPN=12314753; sug=3; sugstore=1; ORIGIN=0; bdime=0; H_PS_645EC=57a3lUay%2BX0JiMHiW4MLgAVVuYlNdJdV0GVodqadhPJtDHr7FYu4FQ104LyGD%2Fc1Z49zY0dY; BD_CK_SAM=1; H_PS_PSSID=17949; BDSVRTM=0; BD_LAST_QID=14777486292203793524
'''
try:
	#Set the whole string
	s.sendall(message)
except socket.error:
	#send Failed
	print 'Send failed'
	sys,exit()
print 'Message send successfully!'
#Now receive data
reply=s.recv(4096)
print reply
s.close()